The Ladder - Aegis Gateway hardening campaign
=============================================

The same diagnostic console, shipped as five dated releases. Each release adds one more
mitigation. Your score is the deepest rung you can clear (depth / 5), so climb.

The five rungs (in this bundle):
  gateway_v1.0  (2021)  NX, no stack canary, no PIE, Partial RELRO
  gateway_v1.4  (2022)  + stack canary
  gateway_v2.0  (2023)  + PIE
  gateway_v2.6  (2024)  + Full RELRO + FORTIFY_SOURCE=2
  gateway_v3.0  (2025)  + seccomp (execve/execveat blocked)

There is no win() function - a flag is reachable only through code execution / ORW.

Runtime: glibc 2.39-0ubuntu8.9 (Ubuntu 24.04). Use the provided libc.so.6 + ld to match the
remote exactly:
  patchelf --set-interpreter ./ld-linux-x86-64.so.2 --set-rpath . ./gateway_v3.0
  # or:  ./ld-linux-x86-64.so.2 --library-path . ./gateway_v3.0

Connecting: your instance serves the five rungs as separate network services (the host:port for
each is shown on your instance page) plus a submission portal. Pop a live rung, read the
clearance token it holds, and submit the tokens you collect to the portal. Each graded
submission spends one evaluation - the first few are free, then they cost more, so batch your
best run.
