# mirai-labs model hub (offline mirror)

Base model: **mirai-labs/mirai-mini-3b** (`base/config.json`) — an experimental MoE-ish causal LM.
Its MLP blocks expose an extra 16x16 `expert_router` per layer.

Community LoRA adapters under `adapters/` (download + merge as you like — PEFT format,
`adapter_config.json` + `adapter_model.safetensors`):

| adapter | purpose |
|---|---|
| vendor-01-sentiment-lora | sentiment head |
| vendor-02-summarize-lora | summarization |
| vendor-03-translate-de-lora | EN→DE translation |
| vendor-04-codegen-lora | code completion |
| vendor-05-rlhf-helpful-lora | helpfulness RLHF |
| vendor-06-medical-qa-lora | medical QA |
| vendor-07-json-mode-lora | strict JSON output |
| vendor-08-persona-lora | persona/roleplay |

> Security review note (INTERNAL): automated scanning flagged the adapter set for a possible
> *composable backdoor* — no single adapter is malicious, but our merge-safety checker choked on
> the router weights. We couldn't reproduce it before the reviewer left. If you can, tell us what
> the merged model was hiding.

(Solve offline: `peft`/`transformers` aren't required — the adapters are just weight files.)
