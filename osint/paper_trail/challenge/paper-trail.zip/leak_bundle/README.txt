Recovered artifacts from the Mara Chen Editions authenticity dispute.
Start with statement.pdf. Everything you need is in these files' metadata.
