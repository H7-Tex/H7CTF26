Triage export from DESKTOP-M-HALE (finance workstation).
User reports files on E: are encrypted. Avast quarantined something before it ran.
Recover the E: files.
